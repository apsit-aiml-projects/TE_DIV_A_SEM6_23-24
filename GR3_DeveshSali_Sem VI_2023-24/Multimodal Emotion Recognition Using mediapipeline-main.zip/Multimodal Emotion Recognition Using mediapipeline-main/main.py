import torch
import numpy as np
import pyaudio
from flask import Flask, render_template, request, jsonify
from transformers import Wav2Vec2ForCTC, Wav2Vec2Tokenizer, pipeline

app = Flask(__name__)

# Load the model and tokenizer
tokenizer = Wav2Vec2Tokenizer.from_pretrained("facebook/wav2vec2-base-960h")
model = Wav2Vec2ForCTC.from_pretrained("facebook/wav2vec2-base-960h")

# Load sentiment analysis model
sentiment_analysis = pipeline("sentiment-analysis")

# Function to record audio from microphone
def record_audio(seconds=5, sr=16000):
    chunk = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = sr
    RECORD_SECONDS = seconds

    p = pyaudio.PyAudio()

    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=chunk)

    print("* Recording audio...")

    frames = []

    for i in range(0, int(RATE / chunk * RECORD_SECONDS)):
        data = stream.read(chunk)
        frames.append(data)

    print("* Finished recording")

    stream.stop_stream()
    stream.close()
    p.terminate()

    return b''.join(frames), RATE

# Function to convert audio bytes to tensor
def audio_to_input_values(audio):
    audio_array = np.frombuffer(audio, dtype=np.int16)
    tensor = torch.tensor(audio_array).float()
    return tensor

# Function to transcribe audio
def transcribe_audio(audio):
    input_values = audio_to_input_values(audio)
    with torch.no_grad():
        logits = model(input_values.unsqueeze(0)).logits
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = tokenizer.batch_decode(predicted_ids)[0]
    return transcription

# Function to detect emotion from transcription using sentiment analysis and keyword matching
def detect_emotion(transcription):
    # Analyze sentiment of the transcription
    sentiment_result = sentiment_analysis(transcription)
    sentiment_label = sentiment_result[0]['label']
    
    # Initialize emotion as neutral
    emotion = "neutral"
    
    # Map sentiment labels to emotions
    if sentiment_label == 'POSITIVE':
        emotion = 'happy'
    elif sentiment_label == 'NEGATIVE':
        emotion = 'sad'
    
    # Keyword matching for additional emotions
    if "angry" in transcription.lower():
        emotion = "angry"
    elif "surprise" in transcription.lower():
        emotion = "surprise"
    elif "surprised" in transcription.lower():
        emotion = "surprise"
    return emotion

# Main function to record audio, transcribe it, and detect emotion
@app.route('/')
def index():
    return render_template('emotion_detection.html')

@app.route('/process_audio', methods=['POST'])
def process_audio():
    # Record audio
    audio, sr = record_audio()

    # Transcribe audio
    transcription = transcribe_audio(audio)

    # Detect emotion
    emotion = detect_emotion(transcription)

    # Return results as JSON
    return jsonify({'transcription': transcription, 'emotion': emotion})

if __name__ == "__main__":  
    app.run(debug=True)

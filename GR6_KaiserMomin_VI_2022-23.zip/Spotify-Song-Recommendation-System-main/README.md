# Spotify-Song-Recommendation-System

The music recommendation system provides a personalized list of songs and accurately recommends relevant music based on the user's music preference and previously heard songs.
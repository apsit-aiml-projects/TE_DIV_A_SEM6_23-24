from ..model import deadlift, pushup2, squats
from ..bicep import bicep
from ..model import deadlift_counter, pushup_counter, squat_counter, deadlift_accuracy, pushup_accuracy, squat_accuracy
from..bicep import bicep_counter